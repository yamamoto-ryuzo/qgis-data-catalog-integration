# -*- coding: utf-8 -*-
"""
/***************************************************************************
 XML Attribute Loader
                                 A QGIS plugin component
 Load XML files as simple attribute tables (no geometry)
                              -------------------
        begin                : 2025-09-20
        copyright            : (C) 2025 by yamamoto-ryuzo
        email                : ryuzo@example.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import xml.etree.ElementTree as ET
from PyQt5.QtCore import QVariant
from qgis.core import (
    QgsVectorLayer, 
    QgsFeature, 
    QgsField, 
    QgsProject, 
    Qgis,
    QgsMessageLog
)


class XmlAttributeLoader:
    """XMLファイルを単純な属性テーブルとして読み込むクラス"""
    
    def __init__(self, iface):
        """
        コンストラクタ
        :param iface: QGIS interface instance
        """
        self.iface = iface
    
    def load_xml_as_attribute_table(self, xml_file_path, layer_name=None):
        """
        XMLファイルを属性テーブル（ジオメトリなし）として読み込む
        
        :param xml_file_path: XMLファイルのパス
        :param layer_name: レイヤ名（指定しない場合はファイル名を使用）
        :return: 作成されたQgsVectorLayer、エラーの場合はNone
        """
        try:
            # ファイルの存在確認
            if not os.path.exists(xml_file_path):
                self._show_error(f"XMLファイルが見つかりません: {xml_file_path}")
                return None
            
            # レイヤ名の設定
            if layer_name is None:
                layer_name = f"XML_Attributes_{os.path.splitext(os.path.basename(xml_file_path))[0]}"
            
            # XMLファイルを解析
            try:
                tree = ET.parse(xml_file_path)
                root = tree.getroot()
            except ET.ParseError as e:
                self._show_error(f"XMLファイルの解析に失敗しました: {str(e)}")
                return None
            
            # XMLの構造を分析してフィールドを自動検出
            fields = self._analyze_xml_structure(root)
            
            if not fields:
                self._show_error("XMLファイルから属性フィールドを検出できませんでした")
                return None
            
            # メモリレイヤを作成（ジオメトリなし）
            layer = QgsVectorLayer("None", layer_name, "memory")
            if not layer.isValid():
                self._show_error("メモリレイヤの作成に失敗しました")
                return None
            
            provider = layer.dataProvider()
            
            # フィールドを追加
            provider.addAttributes(fields)
            layer.updateFields()
            
            # XMLからデータを抽出してフィーチャを作成
            features = self._extract_features_from_xml(root, fields)
            
            if not features:
                self._show_warning("XMLファイルからデータが抽出されませんでした")
            
            # フィーチャをレイヤに追加
            provider.addFeatures(features)
            layer.updateExtents()
            
            # プロジェクトに追加
            QgsProject.instance().addMapLayer(layer)
            
            # 成功メッセージ
            self._show_success(f"XMLファイルが属性テーブルとして読み込まれました: {layer.name()} ({len(features)}件)")
            
            # ログに記録
            QgsMessageLog.logMessage(
                f"XML loaded as attribute table: {xml_file_path} -> {layer.name()} ({len(features)} records)",
                "XML Attribute Loader",
                Qgis.Info
            )
            
            return layer
            
        except Exception as e:
            self._show_error(f"XMLファイルの読み込みに失敗しました: {str(e)}")
            QgsMessageLog.logMessage(
                f"Error loading XML: {str(e)}",
                "XML Attribute Loader",
                Qgis.Critical
            )
            return None
    
    def _analyze_xml_structure(self, root):
        """
        XMLの構造を分析してフィールドリストを生成
        
        :param root: XML root element
        :return: QgsFieldのリスト
        """
        fields = []
        field_names = set()
        
        # まず各要素を調べてフィールド名を収集
        elements = self._find_data_elements(root)
        
        for element in elements[:10]:  # 最初の10要素をサンプルとして分析
            for child in element:
                field_name = child.tag
                if field_name not in field_names:
                    field_names.add(field_name)
                    # フィールドタイプを推定（とりあえず文字列）
                    fields.append(QgsField(field_name, QVariant.String))
        
        # 基本フィールドを追加
        if "xml_id" not in field_names:
            fields.insert(0, QgsField("xml_id", QVariant.Int))
        if "element_path" not in field_names:
            fields.append(QgsField("element_path", QVariant.String))
        
        return fields
    
    def _find_data_elements(self, root):
        """
        XMLからデータ要素を探す
        
        :param root: XML root element
        :return: データ要素のリスト
        """
        # 一般的なデータ要素名を試す
        common_names = ['record', 'item', 'data', 'entry', 'row', 'element']
        
        for name in common_names:
            elements = root.findall(f".//{name}")
            if elements:
                return elements
        
        # 子要素から最も多く出現する要素名を探す
        element_counts = {}
        for child in root.iter():
            if len(list(child)) > 0:  # 子要素を持つ要素
                element_counts[child.tag] = element_counts.get(child.tag, 0) + 1
        
        if element_counts:
            most_common = max(element_counts, key=element_counts.get)
            return root.findall(f".//{most_common}")
        
        # 直接の子要素を返す
        return list(root)
    
    def _extract_features_from_xml(self, root, fields):
        """
        XMLからフィーチャを抽出
        
        :param root: XML root element
        :param fields: フィールドリスト
        :return: QgsFeatureのリスト
        """
        features = []
        elements = self._find_data_elements(root)
        
        field_names = [field.name() for field in fields]
        
        for i, element in enumerate(elements):
            feature = QgsFeature()
            attributes = []
            
            # 各フィールドの値を設定
            for field_name in field_names:
                if field_name == "xml_id":
                    attributes.append(i + 1)
                elif field_name == "element_path":
                    path = self._get_element_path(element)
                    attributes.append(path)
                else:
                    # 子要素から値を取得
                    child = element.find(field_name)
                    if child is not None and child.text is not None:
                        attributes.append(child.text.strip())
                    else:
                        # 属性から値を取得
                        attr_value = element.get(field_name)
                        if attr_value is not None:
                            attributes.append(attr_value)
                        else:
                            attributes.append("")
            
            feature.setAttributes(attributes)
            features.append(feature)
        
        return features
    
    def _get_element_path(self, element):
        """
        要素のXPathを取得
        
        :param element: XML element
        :return: XPath文字列
        """
        path_parts = []
        current = element
        while current is not None:
            path_parts.insert(0, current.tag)
            current = current.getparent() if hasattr(current, 'getparent') else None
        return "/" + "/".join(path_parts)
    
    def _show_error(self, message):
        """エラーメッセージを表示"""
        if self.iface and self.iface.messageBar():
            self.iface.messageBar().pushMessage(
                "XML Attribute Loader", message, level=Qgis.Critical, duration=10)
    
    def _show_warning(self, message):
        """警告メッセージを表示"""
        if self.iface and self.iface.messageBar():
            self.iface.messageBar().pushMessage(
                "XML Attribute Loader", message, level=Qgis.Warning, duration=5)
    
    def _show_success(self, message):
        """成功メッセージを表示"""
        if self.iface and self.iface.messageBar():
            self.iface.messageBar().pushMessage(
                "XML Attribute Loader", message, level=Qgis.Success, duration=3)