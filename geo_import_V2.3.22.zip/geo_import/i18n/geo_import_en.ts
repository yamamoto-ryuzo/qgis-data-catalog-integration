<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CKANBrowserDialogBase</name>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="35"/>
        <source>dlg_base_title</source>
        <translation>Catalog Integration</translation>
    </message>
    <!-- (content copied from CKANBrowser_en.ts) -->
</context>
