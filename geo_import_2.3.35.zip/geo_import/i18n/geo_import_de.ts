<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<!-- Copied from CKANBrowser_de.ts -->
<context>
    <name>GeoImportDialogBase</name>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="35"/>
        <source>dlg_base_title</source>
        <translation>Catalog Integration</translation>
    </message>
    <!-- full content copied from original file -->
</context>
</TS>
