<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GeoImportDialogBase</name>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="35"/>
        <source>dlg_base_title</source>
        <translation>Catalog Integration</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="57"/>
        <source>dlg_base_search_term</source>
        <translation>Search term:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="102"/>
        <source>dlg_base_btn_strt_srch</source>
        <translation>Search</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="112"/>
        <source>dlg_base_btn_show_all</source>
        <translation>List all available datasets</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="127"/>
        <source>dlg_base_filter_to</source>
        <translation>Limit search by category:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="266"/>
        <source>dlg_base_btn_disclaimer</source>
        <translation>Disclaimer</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="299"/>
        <source>dlg_base_srch_rslt</source>
        <translation>Results:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="316"/>
        <source>IDC_lblPage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="340"/>
        <source>dlg_base_btn_lt</source>
        <translation>&lt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="365"/>
        <source>dlg_base_btn_gt</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="389"/>
        <source>dlg_base_descr</source>
        <translation>Description:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="408"/>
        <source>dlg_base_data_list</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Found Data:&lt;br /&gt;Choose dataset for download.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="473"/>
        <source>dlg_base_ressource</source>
        <translation>Resource URL:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="585"/>
        <source>dlg_base_btn_load_data</source>
        <translation>Load Data</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="592"/>
        <source>dlg_base_btn_close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="90"/>
        <source>dlg_base_ttip_search</source>
        <translation>Enter your search term here.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="109"/>
        <source>dlg_base_ttip_show</source>
        <translation>Show all datasets available on the CKAN server</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="168"/>
        <source>dlg_base_ttip_filter</source>
        <translation>Activate checkbox to limit search to this category. Double click on a category lists all it&apos;s datasets.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="337"/>
        <source>dlg_base_ttip_prev</source>
        <translation>previous</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="362"/>
        <source>dlg_base_ttip_next</source>
        <translation>next</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="449"/>
        <source>dlg_base_ttip_data_list</source>
        <translation>Download the selected datasets and try to open them with QGIS. If the Datasets can not be shown the containing directory is opened.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="552"/>
        <source>dlg_base_ttip_copy</source>
        <translation>Copy to Clipboard</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="514"/>
        <source>dlg_base_ttip_resource</source>
        <translation>URL of selected resource</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="517"/>
        <source>?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="259"/>
        <source>dlg_base_btn_select_dataprovider</source>
        <translation>Select CKAN Server</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="208"/>
        <source>dlg_base_current_server</source>
        <translation>Current Server</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="230"/>
        <source>dlg_base_lbl_cache_dir</source>
        <translation>Cache Directory</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="252"/>
        <source>dlg_base_lbl_plugin_version</source>
        <translation>Plugin Version: {}</translation>
    </message>
</context>
</TS>
