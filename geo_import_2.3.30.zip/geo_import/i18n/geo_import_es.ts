<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<!-- Copied from CKANBrowser_es.ts -->
<context>
    <name>CKANBrowserDialogBase</name>
    <message>
        <source>dlg_base_title</source>
        <translation>Navegador de Datos Abiertos (CKAN)</translation>
    </message>
    <!-- full content copied from original file -->
</context>
</TS>
